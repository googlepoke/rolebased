# RoleBased

A Pen created on CodePen.io. Original URL: [https://codepen.io/maniec123/pen/PoLVwov/aa1a23b6f7538de1cebc6c4e04c7b663](https://codepen.io/maniec123/pen/PoLVwov/aa1a23b6f7538de1cebc6c4e04c7b663).

